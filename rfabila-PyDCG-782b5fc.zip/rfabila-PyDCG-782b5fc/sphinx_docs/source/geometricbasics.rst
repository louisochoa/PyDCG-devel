geometricbasics
-------------------------

.. automodule :: geometricbasics
    :members:


   
