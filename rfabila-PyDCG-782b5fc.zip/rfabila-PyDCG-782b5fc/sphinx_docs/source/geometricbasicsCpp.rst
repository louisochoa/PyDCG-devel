GeometricbasicsCpp module
-------------------------

.. automodule :: geometricbasicsCpp
    :members:
