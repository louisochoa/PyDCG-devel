crossing
-------------------------

.. automodule :: crossing
    :members:
