Visualizer2 module
-------------------------

.. automodule :: visualizer2
    :members:
