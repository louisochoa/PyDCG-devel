Datastructures module
-------------------------

.. automodule :: datastructures
    :members:
