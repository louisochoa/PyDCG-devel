Combinatorics module
-------------------------

.. automodule :: combinatorics
    :members:
