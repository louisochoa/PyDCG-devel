Visualizer module
-------------------------

.. automodule :: visualizer
    :members:
