Line module
-------------------------

.. automodule :: line
    :members:
