#include <iostream>
#include <Python.h>

using namespace std;

int main()

{

 cout << "Hello, this is my C++ program on Linux" << endl;

 return 0;

}
